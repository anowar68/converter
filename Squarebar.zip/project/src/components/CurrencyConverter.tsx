import React, { useState } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';
import ConversionResult from './ConversionResult';
import UnitSelector, { Unit } from './UnitSelector';

const units: Unit[] = [
  { name: 'Arab', value: 1000000000 },
  { name: 'Crore', value: 10000000 },
  { name: 'Million', value: 1000000 },
  { name: 'Lakh', value: 100000 },
  { name: 'Thousand', value: 1000 },
  { name: 'Hundred', value: 100 },
  { name: 'Ten', value: 10 },
  { name: 'One', value: 1 },
  { name: 'Tenth', value: 0.1 },
  { name: 'Hundredth', value: 0.01 },
  { name: 'Thousandth', value: 0.001 },
  { name: 'Ten Thousandth', value: 0.0001 },
  { name: 'Lakhth', value: 0.00001 },
  { name: 'Millionth', value: 0.000001 },
  { name: 'Billionth', value: 0.000000001 }
];

const FAQ = [
  {
    question: 'What is the difference between Indian and International number systems?',
    answer: 'The Indian number system uses terms like lakhs and crores, with commas placed at different positions (e.g., 1,00,000), while the International system uses millions and billions with commas every three digits (e.g., 100,000).'
  },
  {
    question: 'How many zeros are in a crore?',
    answer: 'A crore equals 10 million and has 7 zeros (10,000,000). In words, it is written as Ten Million.'
  },
  {
    question: 'What comes after crore in Indian number system?',
    answer: 'After crore comes arab (100 crore), then kharab (100 arab), and then neel (100 kharab). The progression continues with padma, shankh, and so on.'
  },
  {
    question: 'How to convert lakhs to millions?',
    answer: 'To convert lakhs to millions, divide by 10. For example, 10 lakhs = 1 million. This is because 1 million = 10 lakhs.'
  },
  {
    question: 'What is larger: million or crore?',
    answer: 'A crore (10 million) is larger than a million. 1 crore = 10 million = 100 lakhs. In the international system, a crore would be written as 10,000,000.'
  }
];

export default function CurrencyConverter() {
  const [amount, setAmount] = useState<string>('1');
  const [fromUnit, setFromUnit] = useState(units[0]);
  const [toUnit, setToUnit] = useState(units[1]);
  const [openFAQs, setOpenFAQs] = useState<number[]>([]);

  const convert = () => {
    const value = parseFloat(amount);
    if (isNaN(value)) return 0;
    return (value * fromUnit.value) / toUnit.value;
  };

  const toggleFAQ = (index: number) => {
    setOpenFAQs(prev => 
      prev.includes(index) 
        ? prev.filter(i => i !== index)
        : [...prev, index]
    );
  };

  const result = convert();

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 p-6">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-4xl font-bold text-center text-indigo-900 mb-8">
          Number System Converter
        </h1>

        <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
          <div className="prose max-w-none">
            <p className="text-gray-700 leading-relaxed">
              Welcome to our comprehensive Number System Converter! This tool bridges the gap between Indian and International number systems, helping you convert between various units like Crores, Lakhs, Millions, and Billions. Whether you're dealing with financial documents, international transactions, or just learning about different number systems, our converter provides accurate conversions with proper formatting for both Indian and International standards.
            </p>
          </div>
        </div>
        
        <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
          <h2 className="text-2xl font-semibold text-gray-800 mb-6">
            Convert Between Units
          </h2>
          
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Enter Amount
              </label>
              <input
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                placeholder="Enter amount"
              />
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <UnitSelector
                units={units}
                selectedUnit={fromUnit}
                onChange={setFromUnit}
                label="From Unit"
              />
              <UnitSelector
                units={units}
                selectedUnit={toUnit}
                onChange={setToUnit}
                label="To Unit"
              />
            </div>

            <ConversionResult result={result} toUnit={toUnit.name} />
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
          <h3 className="text-2xl font-semibold text-gray-800 mb-6">
            Number System Examples
          </h3>
          
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Indian</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">International</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                <tr>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">1,00,00,00,000 (One Arab)</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">1,000,000,000 (One Billion)</td>
                </tr>
                <tr>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">1,00,00,000 (One Crore)</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">10,000,000 (Ten Million)</td>
                </tr>
                <tr>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">10,00,000 (Ten Lakhs)</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">1,000,000 (One Million)</td>
                </tr>
                <tr>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">1,00,000 (One Lakh)</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">100,000 (Hundred Thousand)</td>
                </tr>
                <tr>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">10,000 (Ten Thousand)</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">10,000 (Ten Thousand)</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-lg p-6">
          <h4 className="text-2xl font-semibold text-gray-800 mb-6">
            Frequently Asked Questions
          </h4>
          
          <div className="space-y-4">
            {FAQ.map((faq, index) => (
              <div key={index} className="border rounded-lg">
                <button
                  className="w-full px-4 py-3 flex justify-between items-center text-left font-medium"
                  onClick={() => toggleFAQ(index)}
                >
                  <span>{faq.question}</span>
                  {openFAQs.includes(index) ? (
                    <ChevronUp className="w-5 h-5 text-indigo-600" />
                  ) : (
                    <ChevronDown className="w-5 h-5 text-indigo-600" />
                  )}
                </button>
                {openFAQs.includes(index) && (
                  <div className="px-4 py-3 border-t bg-gray-50">
                    {faq.answer}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}