import React from 'react';

export interface Unit {
  name: string;
  value: number;
}

interface UnitSelectorProps {
  units: Unit[];
  selectedUnit: Unit;
  onChange: (unit: Unit) => void;
  label: string;
}

export default function UnitSelector({ units, selectedUnit, onChange, label }: UnitSelectorProps) {
  return (
    <div>
      <label className="block text-sm font-medium text-gray-700 mb-1">
        {label}
      </label>
      <select
        value={selectedUnit.name}
        onChange={(e) => {
          const unit = units.find(u => u.name === e.target.value);
          if (unit) onChange(unit);
        }}
        className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 bg-white"
      >
        {units.map((unit) => (
          <option key={unit.name} value={unit.name}>
            {unit.name}
          </option>
        ))}
      </select>
    </div>
  );
}